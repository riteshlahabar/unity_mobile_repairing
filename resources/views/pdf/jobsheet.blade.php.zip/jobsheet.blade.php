<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>JobSheet - {{ $jobSheet->jobsheet_id }}</title>
    <style>
    body {
        font-family: DejaVu Sans, Arial, sans-serif;
        font-size: 12px;
    }

    .header {
        text-align: center;
        margin-bottom: 20px;
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
    }

    .header h1 {
        margin: 0;
        font-size: 24px;
    }

    .section {
        margin-bottom: 15px;
    }

    .section-title {
        font-size: 14px;
        font-weight: bold;
        background: #f0f0f0;
        padding: 5px;
        margin-bottom: 10px;
    }

    .row {
        display: table;
        width: 100%;
        margin-bottom: 5px;
    }

    .col {
        display: table-cell;
        padding: 3px;
    }

    .col-label {
        font-weight: bold;
        width: 30%;
    }

    .footer {
        margin-top: 30px;
        border-top: 1px solid #000;
        padding-top: 10px;
        text-align: center;
        font-size: 10px;
    }

    .sign-row {
        display: table;
        width: 100%;
        margin-top: 40px;
    }

    .signature-box {
        display: table-cell;
        width: 50%;
        text-align: center;
        vertical-align: bottom;
    }

    .sig-line {
        margin-top: 40px;
        border-top: 1px solid #333;
        width: 70%;
        margin-left: auto;
        margin-right: auto;
    }

    .terms-checkbox {
        margin-top: 20px;
        font-size: 12px;
    }

    .checkbox-row {
        display: table;
        width: 100%;
    }

    .checkbox-cell {
        display: table-cell;
        vertical-align: middle;
    }
    </style>
</head>

<body>
    <!-- Header with business info -->
   <div class="header" style="border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; text-align: center;">
    <table style="margin: 0 auto; border-collapse: collapse;">
        <tr>
            <td style="width: 50px; vertical-align: middle;">
                <img src="data:image/png;base64,{{ base64_encode(file_get_contents(public_path('assets/images/logo-sm.png'))) }}" alt="Logo" style="height: 70px; display: block; margin: 0 auto;">
            </td>
            <td style="vertical-align: middle; padding-left: 15px; text-align: center;">
    <h1 style="margin: 0;">{{ $businessInfo->business_name ?? 'Business Name' }}</h1>
    <p style="margin: 0;">
        {{ $businessInfo->address ?? 'Business Address' }}<br>
        Mobile: {{ $businessInfo->mobile_number ?? '' }}
    </p>
</td>
        </tr>
    </table>
</div>


    <!-- JobSheet Details -->
    <div class="section">
        <div class="section-title">JobSheet Details</div>
        <div class="row">
            <div class="col col-label">JobSheet ID:</div>
            <div class="col">{{ $jobSheet->jobsheet_id }}</div>
            <div class="col col-label">Date:</div>
            <div class="col">{{ $jobSheet->created_at->format('d-M-Y h:i A') }}</div>
        </div>
        <div class="row">
            <div class="col col-label">Status:</div>
            <div class="col">{{ ucfirst(str_replace('_', ' ', $jobSheet->status)) }}</div>
        </div>
    </div>

    <!-- Customer Information -->
    <div class="section">
        <div class="section-title">Customer Information</div>
        <div class="row">
            <div class="col col-label">Customer ID:</div>
            <div class="col">{{ $jobSheet->customer->customer_id }}</div>
            <div class="col col-label">Name:</div>
            <div class="col">{{ $jobSheet->customer->full_name }}</div>
        </div>
        <div class="row">
            <div class="col col-label">Address:</div>
            <div class="col">{{ $jobSheet->customer->address }}</div>
        </div>
        <div class="row">
            <div class="col col-label">Contact No.:</div>
            <div class="col">{{ $jobSheet->customer->contact_no }}</div>
            <div class="col col-label">Alternate No.:</div>
            <div class="col">{{ $jobSheet->customer->alternate_no ?? '-' }}</div>
        </div>
        <div class="row">
            <div class="col col-label">WhatsApp No.:</div>
            <div class="col">{{ $jobSheet->customer->whatsapp_no ?? '-' }}</div>
        </div>
    </div>

    <!-- Device Information -->
    <div class="section">
        <div class="section-title">Device Information</div>
        <div class="row">
            <div class="col col-label">Company:</div>
            <div class="col">{{ $jobSheet->company }}</div>
            <div class="col col-label">Model:</div>
            <div class="col">{{ $jobSheet->model }}</div>
        </div>
        <div class="row">
            <div class="col col-label">Color:</div>
            <div class="col">{{ $jobSheet->color }}</div>
            <div class="col col-label">Series:</div>
            <div class="col">{{ $jobSheet->series }}</div>
        </div>
        @if($jobSheet->imei)
        <div class="row">
            <div class="col col-label">IMEI:</div>
            <div class="col">{{ $jobSheet->imei }}</div>
        </div>
        @endif
    </div>

    <!-- Problem Details -->
    <div class="section">
        <div class="section-title">Problem Description</div>
        <p>{{ $jobSheet->problem_description }}</p>
        <div class="row">
            <div class="col">
                @if($jobSheet->status_dead) &#x2713; Dead @endif
                @if($jobSheet->status_damage) &#x2713; Damage @endif
                @if($jobSheet->status_on) &#x2713; On with Problem @endif
            </div>
        </div>
    </div>

    <!-- Device Condition -->
    <div class="section">
        <div class="section-title">Device Condition</div>
        <div class="row">
            <div class="col col-label">Condition:</div>
            <div class="col">{{ ucfirst($jobSheet->device_condition) }}</div>
        </div>
        <div class="row">
            <div class="col col-label">Water Damage:</div>
            <div class="col">{{ ucfirst($jobSheet->water_damage) }}</div>
            <div class="col col-label">Physical Damage:</div>
            <div class="col">{{ ucfirst($jobSheet->physical_damage) }}</div>
        </div>
    </div>

    <!-- Cost Details -->
    <div class="section">
        <div class="section-title">Cost Details</div>
        <div class="row">
            <div class="col col-label">Estimated Cost:</div>
            <div class="col">Rs. {{ number_format($jobSheet->estimated_cost, 2) }}</div>        
            <div class="col col-label">Advance Paid:</div>
            <div class="col">Rs. {{ number_format($jobSheet->advance, 2) }}</div>
        </div>
        <div class="row">
            <div class="col col-label">Balance:</div>
            <div class="col"><strong>Rs. {{ number_format($jobSheet->balance, 2) }}</strong></div>
        </div>
    </div>

    <!-- Technician and Location -->
    @if($jobSheet->technician)
    <div class="section">
        <div class="section-title">Service Information</div>
        <div class="row">
            <div class="col col-label">Technician:</div>
            <div class="col">{{ $jobSheet->technician }}</div>
        
        @if($jobSheet->location)
        
            <div class="col col-label">Location:</div>
            <div class="col">{{ $jobSheet->location }}</div>
        </div>
        @endif
    </div>
    @endif

    <!-- Accessories -->
    <div class="section">
        <div class="section-title">Accessories</div>
        <div class="row">
            <div class="col">
                @if($jobSheet->accessory_sim_tray) &#x2713; Sim Tray @endif
                @if($jobSheet->accessory_sim_card) &#x2713; Sim Card @endif
                @if($jobSheet->accessory_memory_card) &#x2713; Memory Card @endif
                @if($jobSheet->accessory_mobile_cover) &#x2713; Mobile Cover @endif
                @if($jobSheet->other_accessories) &#x2713; {{ $jobSheet->other_accessories }} @endif
            </div>
        </div>
    </div>

    <!-- Pattern/Security -->
    @if($jobSheet->device_password || $jobSheet->pattern_image)
    <div class="section">
        <div class="section-title">Security Information</div>
        @if($jobSheet->device_password)
        <div class="row">
            <div class="col col-label">Device Password:</div>
            <div class="col">{{ $jobSheet->device_password }}</div>
        
        @endif
        @if($jobSheet->pattern_image)
        
            <div class="col col-label">Pattern:</div>
            <div class="col">
                <img src="{{ $jobSheet->pattern_image }}" alt="Pattern"
                    style="max-width: 150px; height: auto; border: 1px solid #ccc;">
            </div>
        </div>
        @endif
    </div>
    @endif

    <!-- Notes -->
    @if($jobSheet->notes)
    <div class="section">
        <div class="section-title">Notes</div>
        <p>{{ $jobSheet->notes }}</p>
    </div>
    @endif

    <!-- Terms & Conditions and Remarks -->
    <div class="section">
        <div class="section-title">Terms & Conditions and Remarks</div>


        <div style="margin-bottom:8px; white-space: pre-wrap;">{{ $generalInfo->terms_conditions ?? 'N/A' }}</div>

        <div class="section-title">Remarks</div>
        <div style="white-space: pre-wrap;">{{ $generalInfo->remarks ?? 'N/A' }}</div>
    </div>

    <!-- Checkbox in one row -->
    <div class="checkbox-row" style="margin-top: 15px;">
        <div class="checkbox-cell" style="width: 20px;">
            <input type="checkbox" checked disabled>
        </div>
        <div class="checkbox-cell">
            I agree to the terms and conditions
        </div>
    </div>
    </div>

    <!-- Signatures in one row -->
    <div class="sign-row">
        <div class="signature-box" style="text-align: left;">
            <div>Customer Signature</div>
        </div>
        <div class="signature-box" style="text-align: right;">
            <div>For {{ $businessInfo->business_name ?? 'Business Name' }}</div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>This is a computer-generated document</p>
    </div>
</body>

</html>